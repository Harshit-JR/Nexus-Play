using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class TournamentsController : ControllerBase
{
    private readonly AppDbContext _context;

    public TournamentsController(AppDbContext context)
    {
        _context = context;
    }

    [HttpGet]
    public IActionResult Get() => Ok(_context.Tournaments.ToList());

    [HttpPost]
    public IActionResult Post([FromBody] Tournament t)
    {
        _context.Tournaments.Add(t);
        _context.SaveChanges();
        return Ok(t);
    }
}