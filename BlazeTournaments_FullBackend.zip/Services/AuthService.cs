public class AuthService
{
    private readonly AppDbContext _context;
    public AuthService(AppDbContext context) => _context = context;

    public User? ValidateUser(string username, string password) =>
        _context.Users.FirstOrDefault(u => u.Username == username && u.Password == password);
}