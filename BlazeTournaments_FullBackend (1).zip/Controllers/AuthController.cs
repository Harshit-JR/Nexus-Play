using Microsoft.AspNetCore.Mvc;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly AppDbContext _context;
    private readonly AuthService _authService;

    public AuthController(AppDbContext context, AuthService authService)
    {
        _context = context;
        _authService = authService;
    }

    [HttpPost("register")]
    public IActionResult Register([FromBody] User user)
    {
        if (_context.Users.Any(u => u.Username == user.Username))
            return BadRequest("User already exists");

        _context.Users.Add(user);
        _context.SaveChanges();
        return Ok("User registered");
    }

    [HttpPost("login")]
    public IActionResult Login([FromBody] User credentials)
    {
        var user = _authService.ValidateUser(credentials.Username, credentials.Password);
        if (user == null)
            return Unauthorized("Invalid credentials");

        return Ok(new { message = "Login successful", role = user.Role });
    }
}